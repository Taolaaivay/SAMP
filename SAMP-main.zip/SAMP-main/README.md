# python2 SAMP-DDOS.py (ip) (port
